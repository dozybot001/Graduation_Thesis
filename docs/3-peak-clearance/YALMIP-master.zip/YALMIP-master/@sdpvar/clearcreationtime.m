function x = clearcreationtime(x)
x.extra.createTime = 0;
