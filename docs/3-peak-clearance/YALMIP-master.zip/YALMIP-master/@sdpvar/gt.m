function y = gt(X,Y)
error('Strict inequalities are not supported (<a href="yalmip.github.io/inside/strictinequalities">learn why</a>)')