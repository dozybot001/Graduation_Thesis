function s = numel(X)
% NUMEL (overloaded)

s = prod(X.dim);